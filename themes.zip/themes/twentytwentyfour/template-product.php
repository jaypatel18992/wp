<?php
/*
Template Name: Custom Products Page
*/

get_header();

echo '<div class="product-grid-container">';

// Display 3 featured products at the top
$featured_args = array(
    'post_type'      => 'product',
    'posts_per_page' => 3,
    'meta_key'       => '_featured',
    'meta_value'     => 'yes',
);
$featured_query = new WP_Query( $featured_args );

if ( $featured_query->have_posts() ) {
    echo '<div class="featured-products">';
    echo '<h2>Featured Products</h2>';
    echo '<div class="product-grid">';
    while ( $featured_query->have_posts() ) {
        $featured_query->the_post();
        wc_get_template_part( 'content', 'product' );
    }
    echo '</div>'; // .product-grid
    echo '</div>'; // .featured-products
    wp_reset_postdata();
}

// Display 6 products after featured products (popular + pricing high to low)
$popular_args = array(
    'post_type'      => 'product',
    'posts_per_page' => 6,
    'orderby'        => 'meta_value_num',
    'order'          => 'DESC',
    'meta_key'       => 'total_sales', // Assuming you use WooCommerce's total sales for popularity
);
$popular_query = new WP_Query( $popular_args );

if ( $popular_query->have_posts() ) {
    echo '<div class="popular-products">';
    echo '<h2>Popular Products</h2>';
    echo '<div class="product-grid">';
    while ( $popular_query->have_posts() ) {
        $popular_query->the_post();
        wc_get_template_part( 'content', 'product' );
    }
    echo '</div>'; // .product-grid
    echo '</div>'; // .popular-products
    wp_reset_postdata();
}

// Display 2 categories: New and Old
$categories = array( 'new', 'old' );

foreach ( $categories as $category ) {
    $cat_args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'product_cat'    => $category,
    );
    $cat_query = new WP_Query( $cat_args );

    if ( $cat_query->have_posts() ) {
        echo '<div class="category-products">';
        echo '<h2>' . ucfirst( $category ) . ' Products</h2>';
        echo '<div class="product-grid">';
        while ( $cat_query->have_posts() ) {
            $cat_query->the_post();
            wc_get_template_part( 'content', 'product' );
        }
        echo '</div>'; // .product-grid
        echo '</div>'; // .category-products
        wp_reset_postdata();
    }
}

echo '</div>'; // .product-grid-container

get_footer();
?>
