<?php

add_filter('use_block_editor_for_post', '__return_false'); 

//frontend  form data submit add in post backend
function custom_post_type() {
    $labels = array(
        'name'                  => _x( 'Developers', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'Developer', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'Developers', 'text_domain' ),
        'name_admin_bar'        => __( 'Developer', 'text_domain' ),
        'archives'              => __( 'Developer Archives', 'text_domain' ),
        'attributes'            => __( 'Developer Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent Developer:', 'text_domain' ),
        'all_items'             => __( 'All Developers', 'text_domain' ),
        'add_new_item'          => __( 'Add New Developer', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New Developer', 'text_domain' ),
        'edit_item'             => __( 'Edit Developer', 'text_domain' ),
        'update_item'           => __( 'Update Developer', 'text_domain' ),
        'view_item'             => __( 'View Developer', 'text_domain' ),
        'view_items'            => __( 'View Developers', 'text_domain' ),
        'search_items'          => __( 'Search Developer', 'text_domain' ),
        'not_found'             => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into Developer', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this Developer', 'text_domain' ),
        'items_list'            => __( 'Developers list', 'text_domain' ),
        'items_list_navigation' => __( 'Developers list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter Developers list', 'text_domain' ),
    );
    $args = array(
        'label'                 => __( 'Developer', 'text_domain' ),
        'description'           => __( 'Developer information post type', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail' ),
        'taxonomies'            => array( 'developer_type' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-admin-users',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );
    register_post_type( 'developer_post', $args );
}
add_action( 'init', 'custom_post_type', 0 );

// Register Custom Taxonomy
function custom_taxonomy() {
    $labels = array(
        'name'                       => _x( 'Developer Types', 'Taxonomy General Name', 'text_domain' ),
        'singular_name'              => _x( 'Developer Type', 'Taxonomy Singular Name', 'text_domain' ),
        'menu_name'                  => __( 'Developer Type', 'text_domain' ),
        'all_items'                  => __( 'All Developer Types', 'text_domain' ),
        'parent_item'                => __( 'Parent Developer Type', 'text_domain' ),
        'parent_item_colon'          => __( 'Parent Developer Type:', 'text_domain' ),
        'new_item_name'              => __( 'New Developer Type Name', 'text_domain' ),
        'add_new_item'               => __( 'Add New Developer Type', 'text_domain' ),
        'edit_item'                  => __( 'Edit Developer Type', 'text_domain' ),
        'update_item'                => __( 'Update Developer Type', 'text_domain' ),
        'view_item'                  => __( 'View Developer Type', 'text_domain' ),
        'separate_items_with_commas' => __( 'Separate Developer types with commas', 'text_domain' ),
        'add_or_remove_items'        => __( 'Add or remove Developer types', 'text_domain' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
        'popular_items'              => __( 'Popular Developer Types', 'text_domain' ),
        'search_items'               => __( 'Search Developer Types', 'text_domain' ),
        'not_found'                  => __( 'Not Found', 'text_domain' ),
        'no_terms'                   => __( 'No Developer types', 'text_domain' ),
        'items_list'                 => __( 'Developer types list', 'text_domain' ),
        'items_list_navigation'      => __( 'Developer types list navigation', 'text_domain' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'developer_type', array( 'developer_post' ), $args );
}
add_action( 'init', 'custom_taxonomy', 0 );

// Create a form shortcode
function developer_form_shortcode() {
    ob_start();
    ?>
    <div id="developer-form-container">
        <form id="developer-form" method="post">
            <input type="text" name="developer_name" placeholder="Developer Name" required>
            <input type="email" name="developer_email" placeholder="Developer Email" required>
            <textarea name="developer_description" placeholder="Developer Description" required></textarea>
            <input type="hidden" name="action" value="submit_developer">
            <?php wp_nonce_field( 'developer_nonce', 'developer_nonce_field' ); ?>
            <button type="submit">Submit</button>
        </form>
        <div id="developer-list-container">
            <!-- Ajax response will be inserted here -->
        </div>
    </div>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#developer-form').on('submit', function(e) {
            e.preventDefault();
            var form = $(this);
            var formData = form.serialize();

            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // WordPress AJAX URL
                data: formData,
                success: function(response) {
                    $('#developer-list-container').html(response);
                    $('#developer-form')[0].reset(); // Reset form fields
                }
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'developer_form', 'developer_form_shortcode' );

// Handle AJAX request in PHP
function submit_developer() {
    check_ajax_referer( 'developer_nonce', 'developer_nonce_field' );

    $name = sanitize_text_field( $_POST['developer_name'] );
    $email = sanitize_email( $_POST['developer_email'] );
    $description = sanitize_textarea_field( $_POST['developer_description'] );

    // Check if email already exists
    $existing_dev = get_posts( array(
        'post_type' => 'developer_post',
        'meta_query' => array(
            array(
                'key' => 'developer_email',
                'value' => $email,
            )
        )
    ) );

    if ( empty( $existing_dev ) ) {
        $new_developer = array(
            'post_title' => $name,
            'post_content' => $description,
            'post_status' => 'publish',
            'post_type' => 'developer_post',
        );

        $developer_id = wp_insert_post( $new_developer );

        if ( $developer_id ) {
            // Set developer email as post meta
            update_post_meta( $developer_id, 'developer_email', $email );

            // Output updated list of developers
            $developers = get_posts( array(
                'post_type' => 'developer_post',
            ) );

            if ( $developers ) {
                foreach ( $developers as $developer ) {
                    ?>
                    <div class="developer">
                        <h3><?php echo esc_html( $developer->post_title ); ?></h3>
                        <p><?php echo esc_html( get_post_meta( $developer->ID, 'developer_email', true ) ); ?></p>
                        <div class="developer-description">
                            <?php echo wp_kses_post( $developer->post_content ); ?>
                        </div>
                    </div>
                    <?php
                }
            }
            die();
        }
    }

    // If email already exists or insertion fails
    echo 'Error: Developer with this email already exists or insertion failed.';
    wp_die();
}
add_action( 'wp_ajax_submit_developer', 'submit_developer' );
add_action( 'wp_ajax_nopriv_submit_developer', 'submit_developer' ); 


//custom cpt size and color and category
// Register Custom Post Type
function custom_post_type_product() {
    $labels = array(
        'name'                  => _x( 'Products', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'Product', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'Products', 'text_domain' ),
        'name_admin_bar'        => __( 'Product', 'text_domain' ),
        'archives'              => __( 'Product Archives', 'text_domain' ),
        'attributes'            => __( 'Product Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent Product:', 'text_domain' ),
        'all_items'             => __( 'All Products', 'text_domain' ),
        'add_new_item'          => __( 'Add New Product', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New Product', 'text_domain' ),
        'edit_item'             => __( 'Edit Product', 'text_domain' ),
        'update_item'           => __( 'Update Product', 'text_domain' ),
        'view_item'             => __( 'View Product', 'text_domain' ),
        'view_items'            => __( 'View Products', 'text_domain' ),
        'search_items'          => __( 'Search Product', 'text_domain' ),
        'not_found'             => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into product', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this product', 'text_domain' ),
        'items_list'            => __( 'Products list', 'text_domain' ),
        'items_list_navigation' => __( 'Products list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter products list', 'text_domain' ),
    );
    $args = array(
        'label'                 => __( 'Product', 'text_domain' ),
        'description'           => __( 'Product information', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'taxonomies'            => array( 'product_color', 'product_size', 'product_category' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-cart',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );
    register_post_type( 'product', $args );
}
add_action( 'init', 'custom_post_type_product', 0 );

// Register Custom Taxonomy for Colors
function custom_taxonomy_colors() {
    $labels = array(
        'name'                       => _x( 'Colors', 'Taxonomy General Name', 'text_domain' ),
        'singular_name'              => _x( 'Color', 'Taxonomy Singular Name', 'text_domain' ),
        'menu_name'                  => __( 'Colors', 'text_domain' ),
        'all_items'                  => __( 'All Colors', 'text_domain' ),
        'parent_item'                => __( 'Parent Color', 'text_domain' ),
        'parent_item_colon'          => __( 'Parent Color:', 'text_domain' ),
        'new_item_name'              => __( 'New Color Name', 'text_domain' ),
        'add_new_item'               => __( 'Add New Color', 'text_domain' ),
        'edit_item'                  => __( 'Edit Color', 'text_domain' ),
        'update_item'                => __( 'Update Color', 'text_domain' ),
        'view_item'                  => __( 'View Color', 'text_domain' ),
        'separate_items_with_commas' => __( 'Separate colors with commas', 'text_domain' ),
        'add_or_remove_items'        => __( 'Add or remove colors', 'text_domain' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
        'popular_items'              => __( 'Popular Colors', 'text_domain' ),
        'search_items'               => __( 'Search Colors', 'text_domain' ),
        'not_found'                  => __( 'Not Found', 'text_domain' ),
        'no_terms'                   => __( 'No colors', 'text_domain' ),
        'items_list'                 => __( 'Colors list', 'text_domain' ),
        'items_list_navigation'      => __( 'Colors list navigation', 'text_domain' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'product_color', array( 'product' ), $args );
}
add_action( 'init', 'custom_taxonomy_colors', 0 );

// Register Custom Taxonomy for Sizes
function custom_taxonomy_sizes() {
    $labels = array(
        'name'                       => _x( 'Sizes', 'Taxonomy General Name', 'text_domain' ),
        'singular_name'              => _x( 'Size', 'Taxonomy Singular Name', 'text_domain' ),
        'menu_name'                  => __( 'Sizes', 'text_domain' ),
        'all_items'                  => __( 'All Sizes', 'text_domain' ),
        'parent_item'                => __( 'Parent Size', 'text_domain' ),
        'parent_item_colon'          => __( 'Parent Size:', 'text_domain' ),
        'new_item_name'              => __( 'New Size Name', 'text_domain' ),
        'add_new_item'               => __( 'Add New Size', 'text_domain' ),
        'edit_item'                  => __( 'Edit Size', 'text_domain' ),
        'update_item'                => __( 'Update Size', 'text_domain' ),
        'view_item'                  => __( 'View Size', 'text_domain' ),
        'separate_items_with_commas' => __( 'Separate sizes with commas', 'text_domain' ),
        'add_or_remove_items'        => __( 'Add or remove sizes', 'text_domain' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
        'popular_items'              => __( 'Popular Sizes', 'text_domain' ),
        'search_items'               => __( 'Search Sizes', 'text_domain' ),
        'not_found'                  => __( 'Not Found', 'text_domain' ),
        'no_terms'                   => __( 'No sizes', 'text_domain' ),
        'items_list'                 => __( 'Sizes list', 'text_domain' ),
        'items_list_navigation'      => __( 'Sizes list navigation', 'text_domain' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'product_size', array( 'product' ), $args );
}
add_action( 'init', 'custom_taxonomy_sizes', 0 );

// Register Custom Taxonomy for Categories
function custom_taxonomy_categories() {
    $labels = array(
        'name'                       => _x( 'Categories', 'Taxonomy General Name', 'text_domain' ),
        'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'text_domain' ),
        'menu_name'                  => __( 'Categories', 'text_domain' ),
        'all_items'                  => __( 'All Categories', 'text_domain' ),
        'parent_item'                => __( 'Parent Category', 'text_domain' ),
        'parent_item_colon'          => __( 'Parent Category:', 'text_domain' ),
        'new_item_name'              => __( 'New Category Name', 'text_domain' ),
        'add_new_item'               => __( 'Add New Category', 'text_domain' ),
        'edit_item'                  => __( 'Edit Category', 'text_domain' ),
        'update_item'                => __( 'Update Category', 'text_domain' ),
        'view_item'                  => __( 'View Category', 'text_domain' ),
        'separate_items_with_commas' => __( 'Separate categories with commas', 'text_domain' ),
        'add_or_remove_items'        => __( 'Add or remove categories', 'text_domain' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
        'popular_items'              => __( 'Popular Categories', 'text_domain' ),
        'search_items'               => __( 'Search Categories', 'text_domain' ),
        'not_found'                  => __( 'Not Found', 'text_domain' ),
        'no_terms'                   => __( 'No categories', 'text_domain' ),
        'items_list'                 => __( 'Categories list', 'text_domain' ),
        'items_list_navigation'      => __( 'Categories list navigation', 'text_domain' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'product_category', array( 'product' ), $args );
}
add_action( 'init', 'custom_taxonomy_categories', 0 );
