<?php
function custom_scripts_footer() {
wp_enqueue_style( 'animate', get_stylesheet_directory_uri() . '/lib/animate/animate.min.css', array(),time());
wp_enqueue_style( 'owlcarousel', get_stylesheet_directory_uri() . '/lib/owlcarousel/assets/owl.carousel.min.css', array(),time());
wp_enqueue_style( 'lightbox', get_stylesheet_directory_uri() . '/lib/lightbox/css/lightbox.min.css', array(),time());
wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() . '/css/bootstrap.min.css', array(),time());
wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/css/style.css', array(),time());
//wp_enqueue_script( 'slick', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.js', array(),time());
wp_enqueue_script( 'ajax-js', get_stylesheet_directory_uri() . '/js/portfolio-ajax.js' , array(),time());
}

add_action( 'get_footer', 'custom_scripts_footer' );
add_filter('use_block_editor_for_post', '__return_false'); 
function custom_post_type() {

// Set UI labels for Custom Post Type
$labels = array(
    'name'                => _x( 'Project', 'Post Type General Name', 'twentythirteen' ),
    'singular_name'       => _x( 'Movie', 'Post Type Singular Name', 'twentythirteen' ),
    'menu_name'           => __( 'Project', 'twentythirteen' ),
    'parent_item_colon'   => __( 'Parent Movie', 'twentythirteen' ),
    'all_items'           => __( 'All Project', 'twentythirteen' ),
    'view_item'           => __( 'View Movie', 'twentythirteen' ),
    'add_new_item'        => __( 'Add New Movie', 'twentythirteen' ),
    'add_new'             => __( 'Add New', 'twentythirteen' ),
    'edit_item'           => __( 'Edit Movie', 'twentythirteen' ),
    'update_item'         => __( 'Update Movie', 'twentythirteen' ),
    'search_items'        => __( 'Search Movie', 'twentythirteen' ),
    'not_found'           => __( 'Not Found', 'twentythirteen' ),
    'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),
);
  
// Set other options for Custom Post Type
  
$args = array(
    'label'               => __( 'project', 'twentythirteen' ),
    'description'         => __( 'Movie news and reviews', 'twentythirteen' ),
    'labels'              => $labels,
    'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
    'hierarchical'        => false,
    'public'              => true,
    'show_ui'             => true,
    'show_in_menu'        => true,
    'show_in_nav_menus'   => true,
    'show_in_admin_bar'   => true,
    'menu_position'       => 5,
    'can_export'          => true,
    'has_archive'         => true,
    'exclude_from_search' => false,
    'publicly_queryable'  => true,
    'capability_type'     => 'page',
    'show_in_rest'        => true,
      
);
  
// Registering your Custom Post Type
register_post_type( 'project', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/

add_action( 'init', 'custom_post_type', 0 );

$categories_labels = array(
	'label' => 'Services',
	'hierarchical' => true,
	'query_var' => true
);

// Register taxonomies for extra post type capabilities
register_taxonomy('service', 'project', $categories_labels);

