jQuery(document).ready(function($) {
    $(document).on('click', '.portfolio-title a, .portfolio-image', function(e) {
        e.preventDefault();
        var postID = $(this).data('post-id');
        
        $.ajax({
            url: portfolioAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'portfolio_load_more',
                post_id: postID
            },
            success: function(response) {
                var post = JSON.parse(response);
                var content = `
                    <div class="portfolio-popup">
                        <h2>${post.title}</h2>
                        <div class="portfolio-content">${post.content}</div>
                        <img src="${post.image}" />
                        <p>${post.text}</p>
                        <a href="#" class="close-popup">Close</a>
                    </div>
                `;
                $('body').append(content);
                $('.close-popup').on('click', function() {
                    $('.portfolio-popup').remove();
                });
            }
        });
    });

    var page = 1;
    $(window).on('scroll', function() {
        if ($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
            page++;
            $.ajax({
                url: portfolioAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'portfolio_load_more',
                    paged: page,
                    limit: 5
                },
                success: function(response) {
                    $('.portfolio-container').append(response);
                }
            });
        }
    });
});
