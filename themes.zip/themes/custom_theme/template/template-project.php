<?php 
/* Template Name: List of Post */
get_header();
?>
<section class="project-portfolio section-top section-bottom">
	<div class="corp-container">
		<?php
$taxonomyName = "service";
$parent_terms = get_terms(array(
    'taxonomy'   => $taxonomyName,
    'parent'     => 0,
    'orderby'    => 'slug',
    'hide_empty' => false
));   

if (!empty($parent_terms) && !is_wp_error($parent_terms)) {
    foreach ($parent_terms as $pterm) {
        echo '<div class="single_cat col-md-3">';
        // Link to parent term
        echo '<h3><a href="' . esc_url(get_term_link($pterm)) . '">' . esc_html($pterm->name) . '</a></h3>'; 
        
        $terms = get_terms(array(
            'taxonomy'   => $taxonomyName,
            'parent'     => $pterm->term_id,
            'orderby'    => 'slug',
            'hide_empty' => false
        ));
        
        if (!empty($terms) && !is_wp_error($terms)) {
            echo '<ul>';
            foreach ($terms as $term) {
                // Link to child term
                echo '<li><a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a></li>'; 
            }
            echo '</ul>';
        }
        
        echo '</div>'; 
    }
}
?>

	</div>
</section>
<?php get_footer();?>