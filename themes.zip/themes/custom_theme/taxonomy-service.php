<?php
get_header(); ?>

<main id="main" class="site-main" role="main">
    <?php
    if ( have_posts() ) : 
        // Display the category name
        $term = get_queried_object();
        echo '<h1>' . esc_html( $term->name ) . '</h1>';
        echo '<p>' . esc_html( $term->description ) . '</p>';

        // Start the Loop
        while ( have_posts() ) : the_post();
            ?>
            <article <?php post_class(); ?>>
                <header class="entry-header">
                    <?php the_title( '<h2 class="entry-title">', '</h2>' ); ?>
                </header><!-- .entry-header -->

                <div class="entry-content">
                    <?php the_excerpt(); ?>
                    <a href="<?php the_permalink(); ?>">Read More</a>
                </div><!-- .entry-content -->
            </article>
            <?php
        endwhile;

        // Pagination
        the_posts_pagination();
        
    else :
        echo '<p>No posts found.</p>';
    endif;
    ?>
</main><!-- #main -->

<?php get_footer(); ?>
