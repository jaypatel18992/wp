<?php

// REMOVE WP EMOJI
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

function remove_parent_theme_js() {
	wp_dequeue_script( 'jquery-fitvids' );
}
add_action( 'wp_print_scripts', 'remove_parent_theme_js' );

/**
 * Enqueue theme scripts and styles.
 */
function siteorigin_corp_child_scripts() {
	wp_dequeue_style('wp-block-library');
	wp_deregister_style('wp-block-library');
	wp_dequeue_style('siteorigin-corp-icons');
	wp_deregister_style('siteorigin-corp-icons');
	wp_dequeue_style('siteorigin-google-web-fonts');
	wp_deregister_style('siteorigin-google-web-fonts');
	wp_dequeue_style('gtranslate-style');
	wp_deregister_style('gtranslate-style');

	// Site-specific stylesheet.
	//wp_enqueue_style( 'slick-css', get_stylesheet_directory_uri() . '/assets/css/slick.css');
	wp_enqueue_style( 'dmhomecare-css', get_stylesheet_directory_uri() . '/assets/css/site-specific.css', array(),time());
	if(!is_front_page()){
		wp_enqueue_style( 'dmhomecare-innerpage-css', get_stylesheet_directory_uri() . '/assets/css/inner-page.css', array(),time());
	}	
}
add_action( 'wp_enqueue_scripts', 'siteorigin_corp_child_scripts', 99);

//load assets in footer
function siteorigin_corp_child_scripts_footer() {
	wp_enqueue_style( 'slick-css', get_stylesheet_directory_uri() . '/assets/css/slick.css', array(),time());
	wp_enqueue_style( 'dmhomecare-icon-css', get_stylesheet_directory_uri() . '/assets/css/icon-style.css', array(),time());
	wp_enqueue_script( 'slick-script', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array(),time());
	wp_enqueue_script ( 'site-specific-script', get_stylesheet_directory_uri() . '/assets/js/site-specific.js', array(),time());
}
add_action( 'get_footer', 'siteorigin_corp_child_scripts_footer' );

/**
 * breadcrumb section in innerpage banner
 */
function siteorigin_corp_child_breadcrumb() {
	$html='<div class="breadcrumb_wrapper">';
	$html.='<a href="'.home_url().'" rel="nofollow">Home</a>';
	if (is_category() || is_single()) {
		$html.='<span class="breadcrumb_separator"> - </span><span>'.get_the_category(' &bull; ').'</span>';
		if (is_single()) {
			$html.='<span class="breadcrumb_separator"> - </span><span>'.get_the_title().'</span>';
		}
	} elseif (is_page()) {
		$html.='<span class="breadcrumb_separator"> > </span><span>'.get_the_title().'</span>';
	} elseif (is_search()) {
		$html.='<span class="breadcrumb_separator"> - </span><span>Search Results for: "<em>'.the_search_query().'</em>"</span>';
	}
	$html.='</div>';
	return $html;
}

add_filter('use_block_editor_for_post', '__return_false', 10);

function register_my_menus() {
	register_nav_menus(
		array(
			'service-menu' => __( 'Service Menu' )
		)
	);
}
add_action( 'init', 'register_my_menus' );

add_filter('wp_nav_menu_objects', 'my_wp_nav_menu_objects', 10, 2);
function my_wp_nav_menu_objects( $items, $args ) {
    foreach( $items as $item ) {
        $img = get_field('manu_item_bg_image', $item);
        if( $img ) {
            $item_output = '<li class="main-services" style="background-image:url(\'' . $img['url'] . '\');"><a href="' . $item->url . '">' . $item->title . '</a></li>';
            $item->title = $item_output;
        }
    }
    return $items;
}
