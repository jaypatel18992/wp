<?php
/**
	 * The theme header.
	 *
	 * This is the template that displays all of the <head> section and everything up until <div class="corp-container">.
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
	 *
	 * @package siteorigin-corp
	 * @license GPL 2.0
	 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>
		<?php if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
		do_action( 'siteorigin_corp_body_top' );
		?>

		<div id="page" class="site">
			<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'siteorigin-corp' ); ?></a>

			<?php if ( class_exists( 'Woocommerce' ) && is_store_notice_showing() ) : ?>
			<div id="topbar">
				<?php siteorigin_corp_woocommerce_demo_store(); ?>
			</div><!-- #topbar -->
			<?php endif; ?>
			<div class="topheader py-2 blue--bg d-none d-md-none d-lg-block">
				<div class="corp-container">
					<div class="contact-info-top d-flex justify-content-between">
						<div class="headertop-left d-flex align-items-center text--black">
							<div class="header-top align-items-center d-flex align-items-center justify-content-end"> 
								<div class="contact-info d-flex align-items-center">
									<span class="icon-phone"></span>
									<a href="tel:16729688488" class="header-cta text-white">+1 (672) 968-8488</a>
								</div>
								<div class="contact-info d-flex align-items-center">
									<span class="icon-mail"></span>
									<a class="cus-text text-white" href="mailto:contact@dmhomecare.ca">contact@dmhomecare.ca</a>
								</div>
							</div>
						</div>

						<div class="headertop-right d-flex align-items-center justify-content-end">
							<ul>
								<li><a href="#" rel="nofollow" target="_blank"><span class="icon-facebook"></span></a></li>
								<li><a href="#" rel="nofollow" target="_blank"><span class="icon-linkedin"></span></a></li>
								<li><a href="#" rel="nofollow" target="_blank"><span class="icon-Instagram"></span></a></li>	
							</ul>
							<a href="#" class="callus-cta button secondary--btn">Make An Appointment</a>
						</div>
					</div>
				</div>
			</div>
			<?php do_action( 'siteorigin_corp_header_before' ); ?>
			<header id="masthead" class="site-header<?php if ( siteorigin_setting( 'header_layout' ) == 'centered' ) echo ' centered';  if ( siteorigin_setting( 'header_sticky' ) ) echo ' sticky'; if ( siteorigin_setting( 'navigation_mobile_menu' ) ) echo ' mobile-menu'; ?>" <?php if ( siteorigin_setting( 'header_scales' ) ) echo 'data-scale-logo="true"' ?> >

				<div class="corp-container">

					<div class="site-header-inner">

						<div class="site-branding">
							<?php siteorigin_corp_display_logo(); ?>
							<?php if ( siteorigin_setting( 'header_site_description' ) ) : ?>
							<p class="site-description"><?php bloginfo( 'description' ); ?></p>
							<?php endif ?>
						</div><!-- .site-branding -->

						<nav id="site-navigation" class="main-navigation <?php if ( siteorigin_setting( 'navigation_menu_link_hover_underline' ) ) echo 'link-underline' ?>">

							<?php $mega_menu_active = function_exists( 'ubermenu' ) || function_exists( 'max_mega_menu_is_enabled' ) && max_mega_menu_is_enabled( 'menu-1' ); ?>

							<?php if ( siteorigin_setting( 'navigation_header_menu' ) ) wp_nav_menu( array( 'theme_location' => 'menu-1', 'menu_id' => 'primary-menu' ) ); ?>

							<?php if ( function_exists( 'is_woocommerce' ) && siteorigin_setting( 'woocommerce_mini_cart' ) && ! $mega_menu_active ) siteorigin_corp_woocommerce_mini_cart(); ?>

							<?php if ( siteorigin_setting( 'navigation_menu_search' ) && ! $mega_menu_active ) : ?>
							<button id="search-button" class="search-toggle" aria-label="<?php esc_attr_e( 'Open Search', 'siteorigin-corp' ); ?>">
								<span class="open"><?php siteorigin_corp_display_icon( 'search' ); ?></span>
							</button>
							<?php endif; ?>

							<?php if ( siteorigin_setting( 'navigation_header_menu' ) && siteorigin_setting( 'navigation_mobile_menu' ) && ! $mega_menu_active ) : ?>
							<a href="#menu" id="mobile-menu-button">
								<?php siteorigin_corp_display_icon( 'menu' ); ?>
								<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'siteorigin-corp' ); ?></span>
							</a>
							<?php endif; ?>

						</nav><!-- #site-navigation -->

						<?php if ( siteorigin_setting( 'navigation_menu_search' ) ) : ?>
						<div id="fullscreen-search">
							<div class="corp-container">
								<span><?php esc_html_e( 'Type and press enter to search', 'siteorigin-corp' ); ?></span>
								<form id="fullscreen-search-form" method="get" action="<?php echo esc_url( site_url() ) ?>">
									<input type="search" name="s" placeholder="" aria-label="<?php esc_attr_e( 'Search for', 'siteorigin-corp' ); ?>" value="<?php echo get_search_query() ?>" />
									<button type="submit" aria-label="<?php esc_attr_e( 'Search', 'siteorigin-corp' ); ?>">
										<?php siteorigin_corp_display_icon( 'search' ); ?>
									</button>
								</form>
							</div>
							<button id="search-close-button" class="search-close-button" aria-label="<?php esc_attr_e( 'Close search', 'siteorigin-corp' ); ?>">
								<span class="close"><?php siteorigin_corp_display_icon( 'close' ); ?></span>
							</button>
						</div><!-- #header-search -->
						<?php endif; ?>

					</div><!-- .site-header-inner -->

				</div><!-- .corp-container -->

			</header><!-- #masthead -->

			<?php do_action( 'siteorigin_corp_content_before' ); ?>

			<div id="content" class="site-content">
				<?php  if(!is_front_page() && !is_404()) { ?>
				<div class="page-banner-area">
					<?php if ( siteorigin_page_setting( 'page_title' ) ) : ?>
					<header class="page-banner-title">
						<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
							<?php if ( function_exists('siteorigin_corp_child_breadcrumb') ) {
	echo siteorigin_corp_child_breadcrumb();
}?>
					</header>
					<?php endif; ?>
				</div>
				<?php } else{
} ?>
				<div class="container-fluid p-0">
					<?php do_action( 'siteorigin_corp_content_top' ); ?>
