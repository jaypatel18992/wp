jQuery(document).ready(function($){
	$('.banner-slider').slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		dots: false,
		arrows: true,
		autoplay: true,
		responsive: [
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
		]
	});

	$('.service-slider').slick({
		infinite: true,
		slidesToShow: 3,
		slidesToScroll: 1,
		dots: false,
		arrows: true,
		autoplay: false,
		prevArrow:"#service_slide_prev",
		nextArrow:"#service_slide_next",
		responsive: [
			{
				breakpoint: 1025,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
		]
	});
});

/* Whatsapp Chat Widget by www.bloggermix.com */
jQuery(document).on("click", "#send-it", function() {
	var a = document.getElementById("chat-input");
	if ("" != a.value) {
		var b = $("#get-number").text(),
			c = document.getElementById("chat-input").value,
			d = "https://web.whatsapp.com/send",
			e = b,
			f = "&text=" + c;
		if (
			/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
				navigator.userAgent
			)
		)
			var d = "whatsapp://send";
		var g = d + "?phone=+1(672)968-8488" + e + f;
		window.open(g, "_blank");
	}
}),

	jQuery(document).on("click", ".close-chat", function() {
	jQuery("#whatsapp-chat")
		.addClass("hide")
		.removeClass("show");
}),
	jQuery(document).on("click", ".blantershow-chat", function() {
	jQuery("#whatsapp-chat")
		.addClass("show")
		.removeClass("hide");
});




