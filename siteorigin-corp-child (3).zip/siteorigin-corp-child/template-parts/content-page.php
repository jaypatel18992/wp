<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package siteorigin-corp
 * @license GPL 2.0 
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( siteorigin_page_setting( 'page_title' ) ) : ?>
	<div class="page-banner-area">
		<?php if ( has_post_thumbnail() && siteorigin_setting( 'pages_featured_image' ) ) : ?>
		<div class="page-banner-image" style="background-image:url('<?php echo get_the_post_thumbnail_url(get_the_ID(),'full'); ?>')">
			<?php the_post_thumbnail(); ?>
		</div>
		<?php endif; ?>
		<header class="page-banner-title">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			<?php if ( function_exists('siteorigin_corp_child_breadcrumb') ) {
				echo siteorigin_corp_child_breadcrumb();
			}?>
		</header><!-- .entry-header -->
	</div>
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();

		wp_link_pages( array(
			'before' => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'siteorigin-corp' ) . '</span>',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		) );
		?>
	</div><!-- .entry-content -->

</article><!-- #post-## -->
