<?php
/**
*
* Template Name: Services-pages
*
* */
get_header(); 
?>
<section class="servie-inner-section section-top section-bottom">
	<div class="corp-container">
		<div class="row">
			<div class="col-12 col-md-9 service-banner-image">
				<?php 
				$image = get_field('services_image');
				if( !empty( $image ) ): ?>
				<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
				<div class="service-text pt-4">
					<?php echo the_content(); ?>
				</div>
			</div>
			<div class="col-12 col-md-3">
				<div class="service-inner-content">
					<?php 
					wp_nav_menu( 
						array( 
							'theme_location' => 'service-menu' 
						) 
					); ?>
<!-- 					<div class="inner-cta mt-5">
						<span class="icon-Phone"></span>
						<h4>Mobile Number!</h4>
						<a href="tel:17783250821">+17783250821</a>
					</div> -->
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer();?>