<?php
/**
*
* Template Name: Contact Us
*
* */
get_header(); 
?>
<section class="contact-info-section section-top section-bottom">
	<div class="corp-container">
		<div class="row">
			<div class="col-12 col-md-6 contact-form-left">
				<?php the_field('contact_us_heading'); ?>
				<div class="contact-details-left">
					<div class="contact-info d-flex">
						<div class="address-icon">
							<span class="icon-location"></span>
						</div>
						<div class="contact-detail">
							<p class="label"><?php the_field('address_label'); ?></p>
							<p><?php the_field('address_info'); ?></p>
						</div>
					</div>
					<div class="contact-info d-flex">
						<div class="phone-icon">
							<span class="icon-phone"></span>
						</div>
						<div class="contact-detail">
							<p class="label"><?php the_field('phone_label'); ?></p>
							<?php 
							$link = get_field('phone_number');
							if( $link ): 
							$link_url = $link['url'];
							$link_title = $link['title'];
							$link_target = $link['target'] ? $link['target'] : '_self';
							?>
							<p><a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></p>
							<?php endif; ?>
						</div>
					</div>
					<div class="contact-info d-flex">
						<div class="email-icon">
							<span class="icon-mail"></span>
						</div>
						<div class="contact-detail">
							<p class="label"><?php the_field('email_label'); ?></p>
							<?php 
							$link = get_field('email_info');
							if( $link ): 
							$link_url = $link['url'];
							$link_title = $link['title'];
							$link_target = $link['target'] ? $link['target'] : '_self';
							?>
							<p><a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></p>
							<?php endif; ?>
						</div>
					</div>
					<div class="contact-info d-flex">
						<div class="opening-hours">
							<span class="icon-working-hours-icon"></span>
						</div>
						<div class="contact-detail">
							<p class="label"><?php the_field('working_hours_label'); ?></p>
							<?php the_field('working_hours_info'); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-6">
				<div class="contact-form-right">
					<?php the_field('quick_enquiry'); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="contactus-map-section">
	<div class="contact-map-loaction"><?php echo get_field('conatct_us_map'); ?></div>
</section>
<?php get_footer();?>