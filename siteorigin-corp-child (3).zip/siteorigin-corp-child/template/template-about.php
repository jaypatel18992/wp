<?php 
/* Template Name: About-Us */
get_header();
?>
<section class="about-info-section section-top">
	<div class="corp-container">
		<?php if( have_rows('about_section') ): ?>
		<?php while( have_rows('about_section') ): the_row(); 
		?>
		<div class="row about-content">
			<div class="col-12 col-md-4 about-img-left">
				<?php 
				$image = get_sub_field('about_image_left');
				if( !empty( $image ) ): ?>
				<img src="<?php echo esc_url($image['url']); ?>"  class="w-100 img-fluid" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
				<?php the_sub_field('profile_name'); ?>
			</div>
			<div class="col-12 col-md-4 about-text section-head">
				<?php the_sub_field('abour_info_text'); ?>
				<?php 
				$link = get_sub_field('read_more_button');
				if( $link ): 
				$link_url = $link['url'];
				$link_title = $link['title'];
				$link_target = $link['target'] ? $link['target'] : '_self';
				?>
				<a class="button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
				<?php endif; ?>
			</div>
			<div class="col-12 col-md-4 contact-info-right">
				<div class="extra-advantage section-head pb-3">
					<h3><?php the_sub_field('extra_advantage_heading'); ?></h3>
					<div class="d-flex align-items-center">
						<span class="icon-arrow-right"></span><?php the_sub_field('extra_advantage'); ?>
					</div>
				</div>
				<div class="contact-details-info text-white">
					<h4><?php the_sub_field('contact_info_heading'); ?></h4>
					<p><span class="icon-Location"></span><?php the_sub_field('address_info'); ?></p>
					<p><span class="icon-Phone"></span>
						<?php 
						$link = get_sub_field('phone_number');
						if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?>
						<a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
						<?php endif; ?>
					</p>
					<p><span class="icon-Mail"></span>
						<?php 
						$link = get_sub_field('email_info');
						if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?>
						<a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
						<?php endif; ?>
					</p>
					<p><span class="icon-global"></span>
						<?php 
						$link = get_sub_field('site_info');
						if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?>
						<a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
						<?php endif; ?>
					</p>
					<div class="service-area-text">
						<?php the_sub_field('service_area_content'); ?>
					</div>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
		<?php endif; ?>
	</div>
</section>
<section class="vision-mission-section section-head">
	<div class="corp-container">
		<div class="row">
			<div class="col-12">
				<?php the_field('vison_text'); ?>
			</div>
			<div class="col-12">
				<?php the_field('mission_text'); ?>
			</div>
		</div> 
	</div>
</section>
<section class="about-bottom-section section-head section-bottom">
	<div class="corp-container">
		<div class="row">
			<div class="col-md-6">
				<?php the_field('service_text'); ?>
			</div>
			<div class="col-md-6">
				<?php the_field('team_text'); ?>
			</div>
		</div> 
	</div>
</section>
<?php get_footer();?>