<?php 
/* Template Name: Gallery */
get_header();
?>
<section class="our-gallery section-top section-bottom">
	<div class="corp-container">
		<div class="photo-gallery-wrapper">
			<?php echo do_shortcode('[rl_gallery id="337"]'); ?>
		</div>
	</div>
</section>
<?php get_footer();?>