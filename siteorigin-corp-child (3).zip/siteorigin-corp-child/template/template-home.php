<?php 
/* Template Name: Home-page */
get_header();
?>
<section class="banner-slide-section">
	<div class="banner-slider">
		<?php
		$images = acf_photo_gallery('banner_slides', $post->ID);
		if( count($images) ):
		foreach($images as $image):
		$title = $image['title']; //The title
		$full_image_url= $image['full_image_url']; //Full size image url
		?>
		<div class="slide-item">
			<img src="<?php echo $full_image_url= $image['full_image_url']; ?>" class="w-100 img-fluid" alt="<?php echo $title; ?>"  loading="lazy">
		</div>
		<?php endforeach; endif; ?>
	</div>
	<div class="bannerslide-txt text-white">
		<?php the_content(); ?>
		<div class="btn-wrapper">
			<?php 
			$link = get_field('slide_button_link');
			if( $link ): 
			$link_url = $link['url'];
			$link_title = $link['title'];
			$link_target = $link['target'] ? $link['target'] : '_self';
			?>
			<a class="btn-readmore" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>
<section class="about-info-section section-top section-bottom">
	<div class="corp-container">
		<?php if( have_rows('about_section') ): ?>
		<?php while( have_rows('about_section') ): the_row(); 
		?>
		<div class="row about-content">
			<div class="col-12 col-md-4 about-img-left">
				<?php 
				$image = get_sub_field('about_image_left');
				if( !empty( $image ) ): ?>
				<img src="<?php echo esc_url($image['url']); ?>"  class="w-100 img-fluid" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
				<?php the_sub_field('profile_name'); ?>
			</div>
			<div class="col-12 col-md-4 about-text">
				<?php the_sub_field('abour_info_text'); ?>
				<?php 
				$link = get_sub_field('read_more_button');
				if( $link ): 
				$link_url = $link['url'];
				$link_title = $link['title'];
				$link_target = $link['target'] ? $link['target'] : '_self';
				?>
				<a class="button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
				<?php endif; ?>
			</div>
			<div class="col-12 col-md-4 contact-info-right">
				<div class="extra-advantage pb-3">
					<h3><?php the_sub_field('extra_advantage_heading'); ?></h3>
					<div class="d-flex align-items-center">
						<span class="icon-arrow-right"></span><?php the_sub_field('extra_advantage'); ?>
					</div>
				</div>
				<div class="contact-details-info text-white">
					<h4><?php the_sub_field('contact_info_heading'); ?></h4>
					<p><span class="icon-Location"></span><?php the_sub_field('address_info'); ?></p>
					<p><span class="icon-Phone"></span>
						<?php 
						$link = get_sub_field('phone_number');
						if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?>
						<a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
						<?php endif; ?>
					</p>
					<p><span class="icon-Mail"></span>
						<?php 
						$link = get_sub_field('email_info');
						if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?>
						<a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
						<?php endif; ?>
					</p>
					<p><span class="icon-global"></span>
						<?php 
						$link = get_sub_field('site_info');
						if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?>
						<a class="phone-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
						<?php endif; ?>
					</p>
					<div class="service-area-text">
						<?php the_sub_field('service_area_content'); ?>
					</div>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
		<?php endif; ?>
	</div>
</section>
<section class="typesofhomecare lightblack--bg section-top section-bottom">
	<div class="corp-container">
		<?php if( have_rows('our_services') ): ?>
		<?php while( have_rows('our_services') ): the_row(); 
		?>
		<div class="care-service-heading text-center">
			<?php the_sub_field('types_of_home_care_heading'); ?>
		</div>
		<div class="service-slider">
			<div class="slide-item">
				<div class="serviceslide-img">
					<?php 
					$image = get_sub_field('dementia_care_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php 
					$link = get_sub_field('dementia_care_link');
					if( $link ): 
					$link_url = $link['url'];
					$link_title = $link['title'];
					$link_target = $link['target'] ? $link['target'] : '_self';
					?>
					<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					<?php endif; ?>
				</div>
				<div class="serviceslide-content">
					<?php the_sub_field('dementia_care'); ?>
				</div>
			</div>
			<div class="slide-item">
				<div class="serviceslide-img">
					<?php 
					$image = get_sub_field('parkinsons_disease_care_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php 
					$link = get_sub_field('parkinsons_disease_care_link');
					if( $link ): 
					$link_url = $link['url'];
					$link_title = $link['title'];
					$link_target = $link['target'] ? $link['target'] : '_self';
					?>
					<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					<?php endif; ?>
				</div>
				<div class="serviceslide-content">
					<?php the_sub_field('parkinsons_disease_care'); ?>
				</div>
			</div>
			<div class="slide-item">
				<div class="serviceslide-img">
					<?php 
					$image = get_sub_field('palliative_care_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php 
					$link = get_sub_field('palliative_care_link');
					if( $link ): 
					$link_url = $link['url'];
					$link_title = $link['title'];
					$link_target = $link['target'] ? $link['target'] : '_self';
					?>
					<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					<?php endif; ?>
				</div>
				<div class="serviceslide-content">
					<?php the_sub_field('palliative_care'); ?>
				</div>
			</div>
			<div class="slide-item">
				<div class="serviceslide-img">
					<?php 
					$image = get_sub_field('postoperative_care_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php 
					$link = get_sub_field('respite_care_link');
					if( $link ): 
					$link_url = $link['url'];
					$link_title = $link['title'];
					$link_target = $link['target'] ? $link['target'] : '_self';
					?>
					<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					<?php endif; ?>
				</div>
				<div class="serviceslide-content">
					<?php the_sub_field('postoperative_care'); ?>
				</div>
			</div>
			<div class="slide-item">
				<div class="serviceslide-img">
					<?php 
					$image = get_sub_field('respite_care_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php 
					$link = get_sub_field('respite_care_link');
					if( $link ): 
					$link_url = $link['url'];
					$link_title = $link['title'];
					$link_target = $link['target'] ? $link['target'] : '_self';
					?>
					<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					<?php endif; ?>
				</div>

				<div class="serviceslide-content">
					<?php the_sub_field('respite_care'); ?>
				</div>
			</div>
			<div class="slide-item">
				<div class="serviceslide-img">
					<?php 
					$image = get_sub_field('transportation_services_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php 
					$link = get_sub_field('transportation_services_link');
					if( $link ): 
					$link_url = $link['url'];
					$link_title = $link['title'];
					$link_target = $link['target'] ? $link['target'] : '_self';
					?>
					<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					<?php endif; ?>
				</div>
				<div class="serviceslide-content">
					<?php the_sub_field('transportation_services'); ?>
				</div>
			</div>
		</div>
		<div class="button-wrapper">
			<a href="javascript:void(0)" id="service_slide_prev"  class="slick-arrow slick-prev">
				<svg xmlns="http://www.w3.org/2000/svg" width="14" height="23" viewBox="0 0 14 23" fill="none">
					<path d="M13 1L2 11.8889L13 22" stroke="black" stroke-width="2"></path>
				</svg>
			</a>
			<a href="javascript:void(0)" id="service_slide_next"  class="slick-arrow slick-next">
				<svg xmlns="http://www.w3.org/2000/svg" width="14" height="23" viewBox="0 0 14 23" fill="none">
					<path d="M13 1L2 11.8889L13 22" stroke="black" stroke-width="2"></path>
				</svg>
			</a>
		</div>
		<?php endwhile; ?>
		<?php endif; ?>
	</div>
</section>
<section class="cta-section">
	<?php if( have_rows('home_cta') ): ?>
	<?php while( have_rows('home_cta') ): the_row(); 
	?>
	<div class="corp- container">
		<div class="row">
			<div class="col-lg-12">
				<div class="divider-current-theme-style2">
					<?php the_sub_field('we_care_about_the_eldery__heading'); ?>
					<div class="icon-box">
						<div class="icon icon-type-img-icon">
							<?php 
							$image = get_sub_field('logo_icon');
							if( !empty( $image ) ): ?>
							<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
							<?php endif; ?>
						</div>
					</div>
					<?php 
					$image = get_sub_field('transportation_services_image');
					if( !empty( $image ) ): ?>
					<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="img-fluid"/>
					<?php endif; ?>
					<?php the_sub_field('in_their_own_homes_heading'); ?>
				</div>
			</div>
		</div>
	</div>
	<div class="layer-image-wrapper layer-image-divider2">
		<div class="layer-image-left" style="background-image:url('<?php the_sub_field('image_left'); ?>');"></div>
		<div class="layer-image-right" style="background-image:url('<?php the_sub_field('image_right'); ?>');"></div>
	</div>
	<?php endwhile; ?>
	<?php endif; ?>
</section>	
<section class="types-of-care section-top section-bottom divider parallax layer-overlay overlay-white-8" data-parallax-ratio="0.1" style="background-image:url('<?php the_field('types_of_care_background'); ?>');">
	<?php if( have_rows('types_of_care') ): ?>
	<?php while( have_rows('types_of_care') ): the_row(); 
	?>
	<div class="corp-container">
		<div class="section-title">
			<div class="row">
				<div class="col-md-12">
					<div class="tm-sc-section-title section-title title-btn-right">
						<div class="title-wrapper d-flex justify-content-between mb-0">
							<div>
								<?php echo get_sub_field('types_of_care_heading'); ?>
							</div>
							<div class="tm-sc-button">
								<?php 
								$link = get_sub_field('cta_button');
								if( $link ): 
								$link_url = $link['url'];
								$link_title = $link['title'];
								$link_target = $link['target'] ? $link['target'] : '_self';
								?>
								<a class="readmore-link button btn-primary" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="section-content">
			<div class="row">
				<div class="col-md-6 col-lg-6 col-xl-4">
					<div class="tm-sc-blog blog-style1-current-theme">
						<article class="post">
							<div class="post-thumb lightgallery-lightbox">
								<div class="post-thumb-inner">
									<div class="thumb">
										<?php 
										$image = get_sub_field('companionship_image');
										if( !empty( $image ) ): ?>
										<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="w-100 img-fluid"/>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<div class="entry-content bg-white">
								<div class="entry-date"><a href="https://api.whatsapp.com/send?phone=+1(672)968-8488&amp;text=Hi,%20I%20Need%20More%20Information%20about%20Your%20Services%20and%20I%20am%20sending%20message%20from%20your%20website%20"><img src="http://localhost/dmhomecare.ca/wp-content/uploads/2024/03/whatsup.webp"></a></div>
								<div class="categorie">
									<?php echo get_sub_field('companionship_description'); ?>
								</div>
								<div class="entry-meta">
									<span>
										<?php 
										$link = get_sub_field('companionship_link');
										if( $link ): 
										$link_url = $link['url'];
										$link_title = $link['title'];
										$link_target = $link['target'] ? $link['target'] : '_self';
										?>
										<a class="readmore-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
										<?php endif; ?></span>
								</div>
							</div>
						</article>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-4">
					<div class="tm-sc-blog blog-style1-current-theme">
						<article class="post">
							<div class="post-thumb lightgallery-lightbox">
								<div class="post-thumb-inner">
									<div class="thumb">
										<?php 
										$image = get_sub_field('personal_care_image');
										if( !empty( $image ) ): ?>
										<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="w-100 img-fluid"/>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<div class="entry-content bg-white">
								<div class="entry-date"><a href="https://api.whatsapp.com/send?phone=+1(672)968-8488&amp;text=Hi,%20I%20Need%20More%20Information%20about%20Your%20Services%20and%20I%20am%20sending%20message%20from%20your%20website%20"><img src="http://localhost/dmhomecare.ca/wp-content/uploads/2024/03/whatsup.webp"></a></div>
								<div class="categorie">
									<?php echo get_sub_field('personal_care_description'); ?>
								</div>
								<div class="entry-meta">
									<span><?php 
										$link = get_sub_field('personal_care_link');
										if( $link ): 
										$link_url = $link['url'];
										$link_title = $link['title'];
										$link_target = $link['target'] ? $link['target'] : '_self';
										?>
										<a class="readmore-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
										<?php endif; ?>
									</span>
								</div>
							</div>
						</article>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-4 offset-md-3 offset-lg-3 offset-xl-0">
					<div class="tm-sc-blog blog-style1-current-theme">
						<article class="post">
							<div class="post-thumb lightgallery-lightbox">
								<div class="post-thumb-inner">
									<div class="thumb">
										<?php 
										$image = get_sub_field('special_care_image');
										if( !empty( $image ) ): ?>
										<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"  class="w-100 img-fluid"/>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<div class="entry-content bg-white">
								<div class="entry-date"><a href="https://api.whatsapp.com/send?phone=+1(672)968-8488&amp;text=Hi,%20I%20Need%20More%20Information%20about%20Your%20Services%20and%20I%20am%20sending%20message%20from%20your%20website%20"><img src="http://localhost/dmhomecare.ca/wp-content/uploads/2024/03/whatsup.webp"></a></div>
								<div class="categorie">
									<?php echo get_sub_field('special_care_description'); ?>
								</div>
								<div class="entry-meta">
									<span>
										<?php 
										$link = get_sub_field('special_care_link');
										if( $link ): 
										$link_url = $link['url'];
										$link_title = $link['title'];
										$link_target = $link['target'] ? $link['target'] : '_self';
										?>
										<a class="readmore-link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
										<?php endif; ?>
									</span>
								</div>
							</div>
						</article>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php endwhile; ?>
	<?php endif; ?>
</section>
<section class="project-gallery-section section-top section-bottom">
	<div class="corp-container">
		<?php if( have_rows('service_gallery') ): ?>
		<?php while( have_rows('service_gallery') ): the_row(); ?>
		<div class="home-project-gallery-wrapper">
			<div class="home-project-gallery-item1" style="background-image:url('<?php the_sub_field('dementia_care_bg'); ?>');">
				<div class="home-project-gallery-content">
					<?php 
					$project_gallery_1_link = get_sub_field('dementia_care_link');
					if( $project_gallery_1_link ): 
					$project_gallery_1_link_url = $project_gallery_1_link['url'];
					$project_gallery_1_link_title = $project_gallery_1_link['title'];
					$project_gallery_1_link_target = $project_gallery_1_link['target'] ? $project_gallery_1_link['target'] : '_self';
					?>
					<a class="view-projects-link" href="<?php echo esc_url( $project_gallery_1_link_url ); ?>" target="<?php echo esc_attr( $project_gallery_1_link_target ); ?>"><h6 class="text-white"> <?php the_sub_field('dementia_care_title'); ?> </h6></a>
					<?php endif; ?>
				</div>
			</div>

			<div class="home-project-gallery-item2" style="background-image:url('<?php the_sub_field('old_age_care_bg'); ?>');">
				<div class="home-project-gallery-content">
					<?php 
					$project_gallery_2_link = get_sub_field('old_age_care_link');
					if( $project_gallery_2_link ): 
					$project_gallery_2_link_url = $project_gallery_2_link['url'];
					$project_gallery_2_link_title = $project_gallery_2_link['title'];
					$project_gallery_2_link_target = $project_gallery_2_link['target'] ? $project_gallery_2_link['target'] : '_self';
					?>
					<a class="view-projects-link" href="<?php echo esc_url( $project_gallery_2_link_url ); ?>" target="<?php echo esc_attr( $project_gallery_2_link_target ); ?>"><h6 class="text-white"> <?php the_sub_field('old_age_care_title'); ?> </h6></a>
					<?php endif; ?>
				</div>
			</div>

			<div class="home-project-gallery-item3" style="background-image:url('<?php the_sub_field('parkinson’s_disease_care_bg'); ?>');">
				<div class="home-project-gallery-content">
					<?php 
					$project_gallery_3_link = get_sub_field('parkinson’s_disease_link');
					if( $project_gallery_3_link ): 
					$project_gallery_3_link_url = $project_gallery_3_link['url'];
					$project_gallery_3_link_title = $project_gallery_3_link['title'];
					$project_gallery_3_link_target = $project_gallery_3_link['target'] ? $project_gallery_3_link['target'] : '_self';
					?>
					<a class="view-projects-link" href="<?php echo esc_url( $project_gallery_3_link_url ); ?>" target="<?php echo esc_attr( $project_gallery_3_link_target ); ?>"><h6 class="text-white"> <?php the_sub_field('parkinson’s_disease_care_title'); ?> </h6></a>
					<?php endif; ?>
				</div>
			</div>

			<div class="home-project-gallery-item4" style="background-image:url('<?php the_sub_field('personal_care_bg'); ?>');">
				<div class="home-project-gallery-content">
					<?php 
					$project_gallery_4_link = get_sub_field('personal_care_link');
					if( $project_gallery_4_link ): 
					$project_gallery_4_link_url = $project_gallery_4_link['url'];
					$project_gallery_4_link_title = $project_gallery_4_link['title'];
					$project_gallery_4_link_target = $project_gallery_4_link['target'] ? $project_gallery_4_link['target'] : '_self';
					?>
					<a class="view-projects-link" href="<?php echo esc_url( $project_gallery_4_link_url ); ?>" target="<?php echo esc_attr( $project_gallery_4_link_target ); ?>"><h6 class="text-white"> <?php the_sub_field('personal_care_title'); ?> </h6></a>
					<?php endif; ?>
				</div>
			</div>

			<div class="home-project-gallery-item5" style="background-image:url('<?php the_sub_field('transportation_services_bg'); ?>');">
				<div class="home-project-gallery-content">
					<?php 
					$project_gallery_5_link = get_sub_field('transportation_services_link');
					if( $project_gallery_5_link ): 
					$project_gallery_5_link_url = $project_gallery_5_link['url'];
					$project_gallery_5_link_title = $project_gallery_5_link['title'];
					$project_gallery_5_link_target = $project_gallery_5_link['target'] ? $project_gallery_5_link['target'] : '_self';
					?>
					<a class="view-projects-link" href="<?php echo esc_url( $project_gallery_5_link_url ); ?>" target="<?php echo esc_attr( $project_gallery_5_link_target ); ?>"><h6 class="text-white"> <?php the_sub_field('transportation_services'); ?> </h6></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
		<?php endif; ?>
	</div>
</section>
<section class="contact-us-section text-center">
	<div class="corp-container">
		<?php echo get_field('contact_us_heading'); ?>
		<?php echo do_shortcode('[contact-form-7 id="1ab958c" title="Home Page"]'); ?>
	</div>
</section>
<?php get_footer();?>